package com.bookcafe.dto;

public class ClubCart {
	private int clubId;
	private int clubQuantity;
	public int getClubId() {
		return clubId;
	}
	public void setClubId(int clubId) {
		this.clubId = clubId;
	}
	public int getClubQuantity() {
		return clubQuantity;
	}
	public void setClubQuantity(int clubQuantity) {
		this.clubQuantity = clubQuantity;
	}
	
	

}

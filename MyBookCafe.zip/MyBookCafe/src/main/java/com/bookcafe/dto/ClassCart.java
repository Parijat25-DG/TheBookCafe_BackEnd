package com.bookcafe.dto;

public class ClassCart {
	
	private int classId;
	private int classQuantity;
	public int getClassId() {
		return classId;
	}
	public void setClassId(int classId) {
		this.classId = classId;
	}
	public int getClassQuantity() {
		return classQuantity;
	}
	public void setClassQuantity(int classQuantity) {
		this.classQuantity = classQuantity;
	}
	
	

}

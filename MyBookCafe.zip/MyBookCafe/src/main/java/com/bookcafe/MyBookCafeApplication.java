package com.bookcafe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyBookCafeApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyBookCafeApplication.class, args);
	}

}

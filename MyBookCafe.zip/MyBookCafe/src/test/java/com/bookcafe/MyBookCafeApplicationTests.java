package com.bookcafe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyBookCafeApplicationTests {

	@Test
	void contextLoads() {
	}

}
